#define REDIS_GIT_SHA1 "00000000"
#define REDIS_GIT_DIRTY "       0"
#define REDIS_BUILD_ID "Camerons-MacBook-Pro.local-1539206494"
