
//Require the RapidAPi
const RapidAPI = new require('rapidapi-connect');
const rapid = new RapidAPI('default-application_5bcf4edbe4b0d1763ed68ac0', '970515d6-0873-4dda-be7b-872cf1e8f958');

//Establishing a connectiong to Express
var express = require('express');
//Establishing a connectiong to Redis
var redis = require('redis');
//Establishing a connectiong to Unirest
var unirest = require('unirest');
//Establishing a connectiong to Body-Parser
//var bodyParser = require('body-parser');
//Creating our App project
var app = express();

//*** Allowing this application read any files we put in the public folder
app.use(express.static('public'));
app.use(express.static('accessfiles'));
//*** Configuring the App to use the body parser
//app.use(bodyParser.urlencoded({extended: true})); // For parsing

var bodyParser = require('body-parser');
app.use(bodyParser.json()); // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true })); // support encoded bodies

//*** Connect to my redis Database
var client = redis.createClient();
client.on('error', function (err){
    console.log(err);
    console.log("Redis is probabbly not running, copy paste this into another terminal window ");
    console.log(" /Users/HomeFolder/Node.JSProjects/Awd211_Security/redis/src/redis-server");
});


//*** Saving Ingredients to the redis-db
app.post('/api/v1/recipe/ingredient/add', function (req, res){
   
    console.log(req.body.value);
    var key = "User_1";
    var ingredients = req.body.value;
    client.set(key, JSON.stringify(ingredients));
    //res.send(ingredients);
});

app.put('/api/v1/recipe/ingredient/remove', function (req, res){
   
    console.log(req.body.value);
    var key = "User_1";
    var ingredients = req.body.value;
    client.set(key, JSON.stringify(ingredients));
    
});

app.get('/api/v1/recipe/search', function(req, res){

    client.get("User_1" , function(err, result){
        
        //CASTING REDIS DATA FROM STRING TO JSON
        console.log("the get result from inside the method is " + result);

        
    var retId = [];
    var retTitle = [];
    var retImg =[];
    var retSteps=[];
    var usedIng=[];
    var unusedIng=[];
    
    
    // **** GET METHOD TO FIND A RECIPE #ID BASED OFF INGREDIENT SEARCH 
    unirest.get("https://spoonacular-recipe-food-nutrition-v1.p.mashape.com/recipes/findByIngredients?ingredients=" + result + "&number=6&ranking=1")
        .header("X-Mashape-Key", "JYQS4ioQ5GmshUk48NUPn3HYYuXMp1d0uDWjsnqstvbauYHXyo")
        .header("X-Mashape-Host", "spoonacular-recipe-food-nutrition-v1.p.mashape.com")
        .end(function (result) {
        
        for(var i=0; i<6; i++){
            retId.push(result.body[i].id);
            retTitle.push(result.body[i].title);
            retImg.push(result.body[i].image);
            usedIng.push(result.body[i].usedIngredientCount);
            unusedIng.push(result.body[i].missedIngredientCount);
            //console.log(result.body);
        }
            
        var recipe ={};
        recipe.id = retId;
        recipe.title = retTitle;
        recipe.img = retImg;
        recipe.steps = retSteps;
        recipe.Ing_used = usedIng;
        recipe.Ing_un_used = unusedIng;
        
        
        res.send(recipe);
        //res.redirect("/recipe.html");


       
    });
        if(err){
            console.log(err); 
        } 
    });
    
    
});
 /*
            // *** GET RECIPE INSTRUCTIONS BASED OFF ID# 
           unirest.get("https://spoonacular-recipe-food-nutrition-v1.p.mashape.com/recipes/" + globeRecID +"/analyzedInstructions?stepBreakdown=false")
            .header("X-Mashape-Key", "JYQS4ioQ5GmshUk48NUPn3HYYuXMp1d0uDWjsnqstvbauYHXyo")
            .header("X-Mashape-Host", "spoonacular-recipe-food-nutrition-v1.p.mashape.com")
            .end(function (result) {
               
               for(var i=0; i<result.body[0].steps.length; i++)
               {
                retSteps.push(result.body[0].steps[i].step);
                
               }  
               console.log(retTitle + " " + retImg + " " + retSteps);
            }); */

app.post('/api/v1/recipe/select', function(req, res){
    var id = req.body.value;
    var idnum = parseInt(id, 10);
    var key = "recipeID";
    console.log(id);
    // TO DO : Use this ID to Search for Title, Img, Instructional Steps on on recipe. Other information bits as well
    client.set(key, id);
})
    
app.get('/api/v1/recipe/main', function(req, res){
    
    client.get("recipeID" , function(err, result){
        
        console.log(result);
        
        unirest.get("https://spoonacular-recipe-food-nutrition-v1.p.mashape.com/recipes/"+ result +"/information")
            .header("X-Mashape-Key", "JYQS4ioQ5GmshUk48NUPn3HYYuXMp1d0uDWjsnqstvbauYHXyo")
            .header("X-Mashape-Host", "spoonacular-recipe-food-nutrition-v1.p.mashape.com")
            .end(function (result) {
              //console.log(result.status, result.headers, result.body);
            res.send(result.body);
            });
    
    
    })
})
//Setting up our App port Listener
console.log('Listening on Port 8888');
app.listen(8888);