﻿var app = angular.module('myApp', []);
app.controller('myCtrl', function($scope, $http) {

            // handle keypress events for autocomplete ingredients search box.

            // this variable will populate the box itself.
            $scope.ingredient = "";

            // this variable will populate the list below the box.
            $scope.lookupinventory = [];

            // this function will get called when the contents of the box changes.
            $scope.keydowningredients = function() {
                $http.get("/data.json").then(function(response) {
                    // myIngredients are the full list of ingredients available from
                    // the Application Programming Interface.
                    var myIngredients = response.data.ingredients;
                    // TODO:  Now loop through and filter my ingredients based upon
                    // what is in the box.
                    $scope.lookupinventory = [];
                    for (var i = 0; i < myIngredients.length; i++) {
                        var ingredient = myIngredients[i];
                        // filter logic for deciding whether an ingredient should show in the
                        // list or not.
                        if (ingredient.name.toUpperCase().indexOf($("#ingredients").val().toUpperCase()) > -1) {
                            $scope.lookupinventory.push(ingredient);
                        }
                    }
                });
            }

            // allows the user to pick ingredients for a recipe they may not actually have
            // in the list.  This could be reprogrammed later to only allow existing ingredients
            // from the list coming from the API or not.
            $scope.add = function ()
            {
                if ($("#ingredients").val().trim().length > 0)
                {
                    var item = {"name": $("#ingredients").val()};
                    $scope.inventory.push(item); 
                } 
            }

            // event is the ingredient in JSON format being passed into this function
            // from my autocomplete lookup component on the index.html page.
            $scope.clickingredient = function(event) {
                $scope.ingredient = event.name;
                $scope.inventory.push(event);
                $('#modaltrigger').click();
                console.log("I clicked on my list item" + event);
            }





            $http.get("/data.json")
                .then(function(response) {
                
                    console.log(response);
                    
                    $scope.inventory = response.data.ingredients;
                    $scope.clear = function() {
                        $scope.inventory = [];
                    }
                    $scope.load = function() {
                        $scope.inventory = response.data.ingredients;
                    }
                    $scope.edit = function() {

                    }
                });
});
